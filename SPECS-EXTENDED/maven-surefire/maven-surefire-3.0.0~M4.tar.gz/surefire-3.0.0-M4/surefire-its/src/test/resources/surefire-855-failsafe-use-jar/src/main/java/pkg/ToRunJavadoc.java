package pkg;

public class ToRunJavadoc
{
    public void x()
    {
    }
}

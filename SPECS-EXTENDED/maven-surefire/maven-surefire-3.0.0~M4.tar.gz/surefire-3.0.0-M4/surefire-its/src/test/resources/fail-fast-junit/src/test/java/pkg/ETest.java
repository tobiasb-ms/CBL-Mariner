package pkg;

import org.junit.Test;

public class ETest
{
    @Test
    public void test()
    {
    }

}

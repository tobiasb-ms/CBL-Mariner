start project 
mvn clean test -Dtest=org.codehaus.SomeFailedTest
package com.example.demo;

import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith( CustomRunner.class )
public class SurefireStreamCorruptionTest
{
    @Test
    public void contextLoads()
    {
    }
}

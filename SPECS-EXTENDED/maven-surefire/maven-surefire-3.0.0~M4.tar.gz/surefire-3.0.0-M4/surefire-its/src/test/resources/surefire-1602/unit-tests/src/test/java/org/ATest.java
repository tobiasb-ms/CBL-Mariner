package org;

import org.junit.Test;

public class ATest
{
    @Test
	public void test()
    {
	}
}

package com.fasterxml.jackson.jaxrs.base;

public abstract class BaseTestBase
    extends junit.framework.TestCase
{
    // for now just placeholder
}

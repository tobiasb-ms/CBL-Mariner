/**
 * Miscellaneous helper classes used by providers.
 */
package com.fasterxml.jackson.jaxrs.util;

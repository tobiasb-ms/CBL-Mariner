# Shared-storage based death #

A highly reliable fencing or Shoot-the-other-node-in-the-head (STONITH) mechanism that works by utilizing shared storage.

The component works with Pacemaker clusters, and is currently known to
compile and function on Pacemaker 1.1.7+ or 2.0.0+ and corosync 1.4.x, 2.3.x or 3.0.x.

Please see https://github.com/clusterlabs/sbd/blob/master/man/sbd.8.pod.in &
https://github.com/clusterlabs/sbd/blob/master/src/sbd.sysconfig for the full documentation.


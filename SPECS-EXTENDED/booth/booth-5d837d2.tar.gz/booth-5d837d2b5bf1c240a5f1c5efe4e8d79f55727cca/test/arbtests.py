from servertests import ServerTests

class ArbitratorConfigTests(ServerTests):
    mode = 'arbitrator'

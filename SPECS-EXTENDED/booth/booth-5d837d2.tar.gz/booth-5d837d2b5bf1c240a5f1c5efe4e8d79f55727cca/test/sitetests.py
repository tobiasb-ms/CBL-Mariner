from servertests import ServerTests

class SiteConfigTests(ServerTests):
    mode = 'site'

Plexus-Compiler
===============

[![Apache License, Version 2.0, January 2004](https://img.shields.io/github/license/codehaus-plexus/plexus-compiler.svg?label=License)](http://www.apache.org/licenses/)
[![Maven Central](https://img.shields.io/maven-central/v/org.codehaus.plexus/plexus-compiler.svg?label=Maven%20Central)](http://search.maven.org/#search%7Cga%7C1%7Cg%3A%22org.codehaus.plexus%22%20a%3A%22plexus-compiler%22)
[![Build Status](https://travis-ci.org/codehaus-plexus/plexus-compiler.svg?branch=master)](https://travis-ci.org/codehaus-plexus/plexus-compiler)

The canonical git repository is located at https://github.com/codehaus-plexus/plexus-compiler


### Error Prone usage 

Please refer to [documentation](https://errorprone.info/docs/installation#maven) 

Or the project [it test](plexus-compiler-its/src/main/it/error-prone-compiler/pom.xml)

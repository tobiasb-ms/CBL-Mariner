package org.codehaus.foo;

public class Deprecation
{
    public Deprecation()
    {
		new java.util.Date("testDate");
    }
}

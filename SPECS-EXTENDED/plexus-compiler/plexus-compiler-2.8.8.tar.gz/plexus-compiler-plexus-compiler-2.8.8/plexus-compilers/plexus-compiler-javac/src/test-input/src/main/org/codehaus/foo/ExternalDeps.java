package org.codehaus.foo;

import org.apache.commons.lang.StringUtils;

public class ExternalDeps
{
	public void hello( String str )
	{
        System.out.println( StringUtils.upperCase( str)  );
	}
}

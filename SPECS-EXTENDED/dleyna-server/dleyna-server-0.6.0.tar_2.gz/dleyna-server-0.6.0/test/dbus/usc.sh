python -i -m upload_sync_controller

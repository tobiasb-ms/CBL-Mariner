python -i -m mediaconsole

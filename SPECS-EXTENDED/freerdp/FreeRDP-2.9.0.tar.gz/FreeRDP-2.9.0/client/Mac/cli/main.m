//
//  main.m
//  MacClient2
//
//  Created by Benoît et Kathy on 2013-05-08.
//
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char *argv[])
{
	return NSApplicationMain(argc, argv);
}

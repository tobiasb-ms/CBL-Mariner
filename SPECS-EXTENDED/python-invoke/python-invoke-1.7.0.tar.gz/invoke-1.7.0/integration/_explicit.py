from invoke import task


@task
def foo(c):
    """
    Frobazz
    """
    print("Yup")

LablTk is an interface to the Tcl/Tk GUI framework. It allows to develop GUI applications in a speedy and type safe way. A legacy Camltk interface is included. The OCamlBrowser library viewer is also part of this project.

The project page is:
https://github.com/garrigue/labltk

You can find information here:
https://garrigue.github.io/labltk/

Bug reports go to Github:
https://github.com/garrigue/labltk/issues
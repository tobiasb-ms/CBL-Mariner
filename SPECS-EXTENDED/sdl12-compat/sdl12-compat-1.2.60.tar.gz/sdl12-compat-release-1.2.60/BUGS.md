
# Reporting bugs

Bugs are now managed in sdl12-compat's GitHub Issues tracker:

https://github.com/libsdl-org/sdl12-compat/issues

You may report bugs there, and search to see if a given issue has already
been reported, discussed, and maybe even fixed.


# Discussion with other humans

You may also find help at the SDL forums:

https://discourse.libsdl.org/

Bug reports are welcome here, but we really appreciate if you use the bug
tracker, as bugs discussed on the forums may be forgotten or missed.


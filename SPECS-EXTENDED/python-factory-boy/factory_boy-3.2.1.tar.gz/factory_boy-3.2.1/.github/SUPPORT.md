# Getting support

Most questions should be asked with the `factory-boy` tag on
[StackOverflow](https://stackoverflow.com/questions/tagged/factory-boy).
Alternatively, a discussion group exists at
https://groups.google.com/d/forum/factoryboy.

Please **do not open issues for support requests**. Issues are meant for bug
reports and improvement suggestions.

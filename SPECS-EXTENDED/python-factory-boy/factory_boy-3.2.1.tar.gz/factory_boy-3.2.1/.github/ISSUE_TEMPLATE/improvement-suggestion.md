---
name: Improvement suggestion
about: Suggest an idea for this project

---

#### The problem
*Please describe the problem you're encountering (e.g "It's very complex to do [...]")*

#### Proposed solution
*Please provide some wild idea you think could solve this issue. It's much easier to work from an existing suggestion :)*

#### Extra notes
*Any notes you feel interesting to include: alternatives you've considered, reasons to include the change, anything!*

from django.apps import AppConfig


class GenericForeignKeyConfig(AppConfig):
    name = 'generic_foreignkey'

===============
 eventletutils
===============

.. automodule:: oslo_utils.eventletutils
   :members:

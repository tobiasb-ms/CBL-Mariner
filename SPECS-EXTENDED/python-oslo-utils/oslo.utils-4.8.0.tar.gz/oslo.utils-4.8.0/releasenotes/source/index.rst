===========================
 oslo.utils Release Notes
===========================

 .. toctree::
    :maxdepth: 1

    unreleased
    victoria
    ussuri
    train
    stein
    rocky
    queens
    pike
    ocata
    newton

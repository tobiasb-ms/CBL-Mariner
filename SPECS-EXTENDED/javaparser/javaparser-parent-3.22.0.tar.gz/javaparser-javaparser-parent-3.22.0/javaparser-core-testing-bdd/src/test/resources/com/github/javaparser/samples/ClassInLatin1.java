// Comment in Latin1:
// A l'�mej in pias� che sent d�sgust.
// For the curios reader, this is Piedmontese dialect
class A {

}
package com.github.javaparser.storage;

public class PrimaryType {
    
}
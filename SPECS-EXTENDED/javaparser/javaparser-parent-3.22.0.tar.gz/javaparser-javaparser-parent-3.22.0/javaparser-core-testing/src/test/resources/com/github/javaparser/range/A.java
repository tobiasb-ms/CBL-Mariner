package com.github.javaparser.range;

public class A {
    public void foo() {
        int a = 42;
    }
}

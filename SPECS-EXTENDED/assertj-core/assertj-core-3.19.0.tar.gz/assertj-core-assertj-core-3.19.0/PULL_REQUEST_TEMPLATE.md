#### Check List:
* Fixes #???
* Unit tests : YES / NO / NA
* Javadoc with a code example (on API only) : YES / NO / NA



<!-- 
# Licensed under the Apache License, Version 2.0 (the "License") http://www.apache.org/licenses/LICENSE-2.0
see https://github.com/vsch/flexmark-java/issues/384
-->

# Media Server Installation

## Install Kurento Media server

<a href="https://doc-kurento.readthedocs.io/en/stable/user/installation.html">Install Kurento Media server</a>
<div class="bd-callout bd-callout-danger">
	It should be run under same user as OM
</div>

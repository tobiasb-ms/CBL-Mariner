This is a [link to be rewritten](doc.md).
This is a [link to be left untouched](ftp://doc.md).


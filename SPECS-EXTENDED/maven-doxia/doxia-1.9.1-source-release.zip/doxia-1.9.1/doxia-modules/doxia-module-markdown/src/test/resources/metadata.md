title: A title
author: Somebody
date: 2013

# The document

Some text

## A subheading

Some more text
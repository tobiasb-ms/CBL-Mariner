`This is Monospaced text.`

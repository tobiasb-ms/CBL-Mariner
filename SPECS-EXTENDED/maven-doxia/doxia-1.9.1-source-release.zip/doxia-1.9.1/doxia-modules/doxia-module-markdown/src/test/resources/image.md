This is an image: ![example](http://example).

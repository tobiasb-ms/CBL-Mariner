# frozen_string_literal: true

require_relative './support/test_case'
require_relative './support/formatter_test_case'
require_relative './support/text_formatter_test_case'

This is a test resouce for the Http2Server example

.. automodule:: scipy.optimize
   :no-members:
   :no-inherited-members:
   :no-special-members:

.. toctree::
   :hidden:
   :maxdepth: 1

   optimize.cython_optimize

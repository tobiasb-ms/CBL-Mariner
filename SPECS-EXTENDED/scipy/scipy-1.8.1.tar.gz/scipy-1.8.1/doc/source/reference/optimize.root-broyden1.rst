.. _optimize.root-broyden1:

root(method='broyden1')
--------------------------------------

.. scipy-optimize:function:: scipy.optimize.root
   :impl: scipy.optimize._root._root_broyden1_doc
   :method: broyden1

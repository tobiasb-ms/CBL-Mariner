.. automodule:: scipy.linalg
   :no-members:
   :no-inherited-members:
   :no-special-members:

.. toctree::
   :hidden:

   linalg.blas
   linalg.lapack
   linalg.cython_blas
   linalg.cython_lapack
   linalg.interpolative

extern const char * _indicator_service;

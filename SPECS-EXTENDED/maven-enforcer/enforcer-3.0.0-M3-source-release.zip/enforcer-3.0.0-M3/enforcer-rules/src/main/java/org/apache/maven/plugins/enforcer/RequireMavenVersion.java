package org.apache.maven.plugins.enforcer;

/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

import org.apache.maven.artifact.versioning.DefaultArtifactVersion;
import org.apache.maven.enforcer.rule.api.EnforcerRuleException;
import org.apache.maven.enforcer.rule.api.EnforcerRuleHelper;
import org.apache.maven.execution.MavenSession;
import org.codehaus.plexus.component.configurator.expression.ExpressionEvaluationException;

/**
 * This rule checks that the Maven version is allowed.
 *
 * @author <a href="mailto:brianf@apache.org">Brian Fox</a>
 */
public class RequireMavenVersion
    extends AbstractVersionEnforcer
{
    @Override
    public void execute( EnforcerRuleHelper helper )
        throws EnforcerRuleException
    {
        try
        {
            MavenSession mavenSession = (MavenSession) helper.evaluate( "${session}" );
            String mavenVersion = mavenSession.getSystemProperties().getProperty( "maven.version" );
            helper.getLog().debug( "Detected Maven Version: " + mavenVersion );
            DefaultArtifactVersion detectedVersion = new DefaultArtifactVersion( mavenVersion );
            enforceVersion( helper.getLog(), "Maven", getVersion(), detectedVersion );
        }
        catch ( ExpressionEvaluationException e )
        {
            throw new EnforcerRuleException( "Unable to retrieve the session.", e );
        }

    }

}

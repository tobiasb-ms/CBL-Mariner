This package contains some classes copied from the container before it started using the "default" role hints.

This can be removed once all supported maven versions are using a container newer than 1.0-alpha-19.
/**
 * @plexus.component
 */
public class Component
{
}


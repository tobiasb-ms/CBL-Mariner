package org.codehaus.plexus;

public interface Executor
{
    String execute();
}

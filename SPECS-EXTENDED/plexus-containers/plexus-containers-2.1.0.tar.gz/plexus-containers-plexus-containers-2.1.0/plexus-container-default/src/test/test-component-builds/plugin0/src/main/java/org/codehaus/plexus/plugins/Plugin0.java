package org.codehaus.plexus.plugins;

public interface Plugin0
{
   public void hello();
}

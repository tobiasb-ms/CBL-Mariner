package org.codehaus.plexus.plugins;

public interface Plugin1
{
   public void hello();
}

package org.codehaus.plexus.components;

public interface B
{
   public void hello();
}

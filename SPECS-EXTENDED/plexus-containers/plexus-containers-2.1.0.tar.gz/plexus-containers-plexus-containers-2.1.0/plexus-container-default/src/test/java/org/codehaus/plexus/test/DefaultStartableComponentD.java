package org.codehaus.plexus.test;

public class DefaultStartableComponentD
    extends AbstractStartableComponent
{
}

package org.codehaus.plexus.test;

public class DefaultStartableComponentC
    extends AbstractStartableComponent
{
}

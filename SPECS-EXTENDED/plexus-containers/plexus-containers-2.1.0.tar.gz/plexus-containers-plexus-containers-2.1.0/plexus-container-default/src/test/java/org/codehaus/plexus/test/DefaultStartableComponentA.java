package org.codehaus.plexus.test;

public class DefaultStartableComponentA
    extends AbstractStartableComponent
{
}

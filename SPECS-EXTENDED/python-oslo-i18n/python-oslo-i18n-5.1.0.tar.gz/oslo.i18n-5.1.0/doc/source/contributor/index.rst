===========================
 Contributing to oslo.i18n
===========================

.. toctree::
   :maxdepth: 2

   contributing
   policy

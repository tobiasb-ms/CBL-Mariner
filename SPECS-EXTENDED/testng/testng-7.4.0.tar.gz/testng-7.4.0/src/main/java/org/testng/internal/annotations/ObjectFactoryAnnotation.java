package org.testng.internal.annotations;

import org.testng.annotations.IObjectFactoryAnnotation;

/**
 * The internal representation of @ObjectFactory
 */
public class ObjectFactoryAnnotation extends BaseAnnotation implements IObjectFactoryAnnotation {}

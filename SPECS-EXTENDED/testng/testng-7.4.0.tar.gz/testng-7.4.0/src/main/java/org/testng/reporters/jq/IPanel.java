package org.testng.reporters.jq;

import org.testng.reporters.XMLStringBuffer;

public interface IPanel {
  void generate(XMLStringBuffer xsb);
}

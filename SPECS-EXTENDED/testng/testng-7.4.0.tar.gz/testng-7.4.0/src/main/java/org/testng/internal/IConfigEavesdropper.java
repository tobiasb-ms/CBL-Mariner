package org.testng.internal;

import org.testng.IResultMap;

public interface IConfigEavesdropper {
  IResultMap getConfigurationsScheduledForInvocation();
}

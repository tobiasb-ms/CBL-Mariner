package org.testng;

/** Parent interface of all the object factories. */
public interface ITestObjectFactory {}

package org.testng.junit;

/** @author lukas */
interface JUnitTestRecognizer {

  boolean isTest(Class c);
}

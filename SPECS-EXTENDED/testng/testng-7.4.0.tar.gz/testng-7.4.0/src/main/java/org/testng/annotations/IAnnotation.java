package org.testng.annotations;

/**
 * The parent interface for all the annotations.
 */
public interface IAnnotation {}

jackson-parent
==============

Project for parent pom for all Jackson components

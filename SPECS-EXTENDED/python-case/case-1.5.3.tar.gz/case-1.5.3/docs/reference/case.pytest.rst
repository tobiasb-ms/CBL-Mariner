=====================================================
 ``case.pytest``
=====================================================

.. contents::
    :local:
.. currentmodule:: case.pytest

.. automodule:: case.pytest
    :members:
    :undoc-members:

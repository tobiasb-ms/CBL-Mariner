=====================================================
 ``case.skip``
=====================================================

.. contents::
    :local:
.. currentmodule:: case.skip

.. automodule:: case.skip
    :members:
    :undoc-members:

=====================================================
 ``case``
=====================================================

.. contents::
    :local:
.. currentmodule:: case

.. automodule:: case
    :members:
    :undoc-members:

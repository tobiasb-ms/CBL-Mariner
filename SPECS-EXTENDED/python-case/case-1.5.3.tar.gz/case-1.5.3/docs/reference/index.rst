.. _apiref:

===============
 API Reference
===============

:Release: |version|
:Date: |today|

.. toctree::
    :maxdepth: 1

    case
    case.case
    case.skip
    case.mock
    case.pytest
    case.utils

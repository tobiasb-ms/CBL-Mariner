=====================================================
 ``case.utils``
=====================================================

.. contents::
    :local:
.. currentmodule:: case.utils

.. automodule:: case.utils
    :members:
    :undoc-members:

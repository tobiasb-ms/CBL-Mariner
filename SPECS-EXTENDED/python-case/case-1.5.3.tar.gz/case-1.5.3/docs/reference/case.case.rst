=====================================================
 ``case.case``
=====================================================

.. contents::
    :local:
.. currentmodule:: case.case

.. automodule:: case.case

    .. autoclass:: CaseMixin
    .. autoclass:: Case

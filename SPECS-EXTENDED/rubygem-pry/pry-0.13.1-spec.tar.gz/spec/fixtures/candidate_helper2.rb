# frozen_string_literal: true

# rank 1
class CandidateTest
  def test4; end

  def test5; end
end

# frozen_string_literal: true

# rank 0
class CandidateTest
  def test1; end

  def test2; end

  def test3; end
end

# frozen_string_literal: true

# rubocop:disable Layout/EmptyLineBetweenDefs
class Cor
  def a; end
  def b; end
  def c; end
  def d; end
end
# rubocop:enable Layout/EmptyLineBetweenDefs

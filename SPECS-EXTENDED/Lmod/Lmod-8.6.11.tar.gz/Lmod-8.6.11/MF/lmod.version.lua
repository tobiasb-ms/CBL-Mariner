-- -*- lua -*-
whatis("Description: Lmod: An Environment Module System")
prepend_path('PATH','@PKG@/libexec')

Please look at the SitePackage.lua file in this directory and modify it to suit
your site's needs.


clusterDescriptT = {
   ping_options = "-c 1 -w 1",
   hostType = {
      login         = {'staff', 'login1', 'login2', 'login3', 'login4', 'login5',},
      bigmem        = {'c400-116',},
      compute_devel = {'c557-901',},
      compute       = {'c486-101'},
      vis           = {'c443-901'},
   }
}




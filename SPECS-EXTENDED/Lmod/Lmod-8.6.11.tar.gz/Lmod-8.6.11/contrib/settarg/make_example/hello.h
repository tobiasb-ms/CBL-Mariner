#ifndef HELLO_H
#define HELLO_H

#include <stdio.h>
void hello(void);

#endif /* HELLO_H */

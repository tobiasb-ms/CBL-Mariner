#include "hello.h"

void hello()
{
  printf("hello world!\n");
}


setenv("LMOD_B_DIR", "/d/e/f")

setenv("LMOD_A_DIR", "/a/b/c")

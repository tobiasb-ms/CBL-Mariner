setenv("Version",myModuleVersion())

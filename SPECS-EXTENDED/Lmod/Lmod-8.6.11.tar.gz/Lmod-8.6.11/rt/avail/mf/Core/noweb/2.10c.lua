-- -*- lua -*-

------------------------------------------------------------------------
-- Noweb 2.10c
------------------------------------------------------------------------

prepend_path('PATH',    '/vol/local/noweb/2.10c/bin')
prepend_path('PATH',    '/vol/local/noweb/icon/bin')
prepend_path('MANPATH', '/vol/local/noweb/noweb/man')

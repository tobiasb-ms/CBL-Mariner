
setenv("JUNK","RTM_1")

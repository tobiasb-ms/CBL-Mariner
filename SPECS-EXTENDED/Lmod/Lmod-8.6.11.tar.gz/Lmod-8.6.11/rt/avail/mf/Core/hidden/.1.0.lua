setenv("MY_VERSION",myModuleVersion())

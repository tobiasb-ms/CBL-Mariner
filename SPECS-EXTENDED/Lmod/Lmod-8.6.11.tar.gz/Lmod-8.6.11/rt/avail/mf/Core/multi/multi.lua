prepend_path("PATH", "/a/b/c:/d/e/f:/g/h/i")
append_path("PATH",  "/abc/def:/qrs/tuv")


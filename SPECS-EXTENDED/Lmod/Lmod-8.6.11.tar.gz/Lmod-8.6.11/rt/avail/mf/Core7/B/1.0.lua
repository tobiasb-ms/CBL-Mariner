if (isAvail("C")) then
   LmodMessage("Found C")
end

if (isAvail("D")) then
   LmodMessage("Found D")
else
   LmodMessage("D Not found")
end
   

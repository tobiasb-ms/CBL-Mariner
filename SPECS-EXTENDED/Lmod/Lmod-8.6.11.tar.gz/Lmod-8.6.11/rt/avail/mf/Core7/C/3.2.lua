setenv("C", "foo")

mod api;
mod methods;

pub use api::get_report_method;

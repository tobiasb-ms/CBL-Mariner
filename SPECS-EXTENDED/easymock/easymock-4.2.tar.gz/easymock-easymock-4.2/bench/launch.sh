#!/usr/bin/env bash

java -jar target/benchmarks.jar ".*"

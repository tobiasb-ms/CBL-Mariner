# spec-version-maven-plugin

This plugin provide help generate and verify specification metadata in JavaEE API artifacts.
See versioning rules: https://javaee.github.io/glassfish/wiki-archive/Maven%20Versioning%20Rules.html

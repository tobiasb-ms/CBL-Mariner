require 'json'
require 'simplecov'
SimpleCov.root(File.expand_path(File.dirname(__FILE__) + '/..'))

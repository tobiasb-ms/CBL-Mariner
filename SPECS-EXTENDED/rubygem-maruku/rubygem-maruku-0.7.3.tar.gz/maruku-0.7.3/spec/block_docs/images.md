Write a comment abouth the test here.
*** Parameters: ***
{}
*** Markdown input: ***

This page does not utilize ![Cascading Style Sheets](http://jigsaw.w3.org/css-validator/images/vcss)


Please mouseover to see the title: ![Cascading Style Sheets](http://jigsaw.w3.org/css-validator/images/vcss "Title ok!")

Please mouseover to see the title: ![Cascading Style Sheets](http://jigsaw.w3.org/css-validator/images/vcss 'Title ok!')


I'll say it one more time: this page does not use ![Cascading Style Sheets] [css]

This is double size: ![Cascading Style Sheets] [css2]



[css]: http://jigsaw.w3.org/css-validator/images/vcss "Optional title attribute"

[css2]: http://jigsaw.w3.org/css-validator/images/vcss "Optional title attribute" class=external
   style="border:0;width:188px;height:131px"



*** Output of inspect ***
md_el(:document,[
	md_par([
		"This page does not utilize ",
		md_im_image(["Cascading Style Sheets"], "http://jigsaw.w3.org/css-validator/images/vcss", nil)
	]),
	md_par([
		"Please mouseover to see the title: ",
		md_im_image(["Cascading Style Sheets"], "http://jigsaw.w3.org/css-validator/images/vcss", "Title ok!")
	]),
	md_par([
		"Please mouseover to see the title: ",
		md_im_image(["Cascading Style Sheets"], "http://jigsaw.w3.org/css-validator/images/vcss", "Title ok!")
	]),
	md_par([
		"I",
		md_entity("rsquo"),
		"ll say it one more time: this page does not use ",
		md_image(["Cascading Style Sheets"], "css")
	]),
	md_par([
		"This is double size: ",
		md_image(["Cascading Style Sheets"], "css2")
	]),
	md_ref_def("css", "http://jigsaw.w3.org/css-validator/images/vcss", {:title=>"Optional title attribute"}),
	md_ref_def("css2", "http://jigsaw.w3.org/css-validator/images/vcss", {:title=>"Optional title attribute"})
],{},[])
*** Output of to_html ***
<p>This page does not utilize <img src="http://jigsaw.w3.org/css-validator/images/vcss" alt="Cascading Style Sheets" /></p>

<p>Please mouseover to see the title: <img src="http://jigsaw.w3.org/css-validator/images/vcss" alt="Cascading Style Sheets" title="Title ok!" /></p>

<p>Please mouseover to see the title: <img src="http://jigsaw.w3.org/css-validator/images/vcss" alt="Cascading Style Sheets" title="Title ok!" /></p>

<p>I’ll say it one more time: this page does not use <img src="http://jigsaw.w3.org/css-validator/images/vcss" alt="Cascading Style Sheets" title="Optional title attribute" /></p>

<p>This is double size: <img src="http://jigsaw.w3.org/css-validator/images/vcss" alt="Cascading Style Sheets" title="Optional title attribute" /></p>
*** Output of to_latex ***
This page does not utilize 

Please mouseover to see the title: 

Please mouseover to see the title: 

I'll say it one more time: this page does not use 

This is double size:
*** Output of to_md ***
This page does not utilize
![Cascading Style Sheets](http://jigsaw.w3.org/css-validator/images/vcss)

Please mouseover to see the title:
![Cascading Style Sheets](http://jigsaw.w3.org/css-validator/images/vcss "Title ok!")

Please mouseover to see the title:
![Cascading Style Sheets](http://jigsaw.w3.org/css-validator/images/vcss "Title ok!")

I'll say it one more time: this
page does not use
![Cascading Style Sheets][css]

This is double size:
![Cascading Style Sheets][css2]

[css]: http://jigsaw.w3.org/css-validator/images/vcss "Optional title attribute"

[css2]: http://jigsaw.w3.org/css-validator/images/vcss "Optional title attribute" class=external
   style="border:0;width:188px;height:131px"
*** Output of to_s ***
This page does not utilize Cascading Style SheetsPlease mouseover to see the title: Cascading Style SheetsPlease mouseover to see the title: Cascading Style SheetsIll say it one more time: this page does not use Cascading Style SheetsThis is double size: Cascading Style Sheets

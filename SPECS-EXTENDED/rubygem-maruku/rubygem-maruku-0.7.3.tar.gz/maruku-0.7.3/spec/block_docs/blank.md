Write a comment about the test here.
*** Parameters: ***
{}
*** Markdown input: ***

Linea 1

Linea 2
*** Output of inspect ***
md_el(:document,[md_par(["Linea 1"]), md_par(["Linea 2"])],{},[])
*** Output of to_html ***
<p>Linea 1</p>

<p>Linea 2</p>
*** Output of to_latex ***
Linea 1

Linea 2
*** Output of to_md ***
Linea 1

Linea 2
*** Output of to_s ***
Linea 1Linea 2

Write a comment abouth the test here.
*** Parameters: ***
{}
*** Markdown input: ***
Paragraph

*** Output of inspect ***
md_el(:document,[md_par(["Paragraph"])],{},[])
*** Output of to_html ***
<p>Paragraph</p>
*** Output of to_latex ***
Paragraph
*** Output of to_md ***
Paragraph
*** Output of to_s ***
Paragraph

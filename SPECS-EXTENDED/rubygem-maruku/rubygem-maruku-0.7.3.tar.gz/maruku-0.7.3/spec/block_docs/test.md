Write a comment abouth the test here.
*** Parameters: ***
{}
*** Markdown input: ***

           $ python       



*** Output of inspect ***
md_el(:document,[md_el(:code,[],{:raw_code=>"       $ python       ", :lang=>nil},[])],{},[])
*** Output of to_html ***
<pre><code>       $ python       </code></pre>
*** Output of to_latex ***
\begin{verbatim}       $ python       \end{verbatim}
*** Output of to_md ***

*** Output of to_s ***


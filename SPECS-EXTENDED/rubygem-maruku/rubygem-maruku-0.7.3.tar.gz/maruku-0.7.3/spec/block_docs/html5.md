Write a comment here
*** Parameters: ***
{} # params 
*** Markdown input: ***
 <div class="frame">
 <a class="photo" href="http://www.flickr.com/photos/censi/88561568/" ><img moz-do-not-send="true" src="http://static.flickr.com/28/88561568_ab84d28245_m.jpg" width="240" height="180" alt="Aperitif" /></a>
 </div>


*** Output of inspect ***
md_el(:document,[
	md_html(" <div class=\"frame\">\n <a class=\"photo\" href=\"http://www.flickr.com/photos/censi/88561568/\" ><img moz-do-not-send=\"true\" src=\"http://static.flickr.com/28/88561568_ab84d28245_m.jpg\" width=\"240\" height=\"180\" alt=\"Aperitif\" /></a>\n </div>")
],{},[])
*** Output of to_html ***
<div class="frame">
 <a class="photo" href="http://www.flickr.com/photos/censi/88561568/"><img moz-do-not-send="true" src="http://static.flickr.com/28/88561568_ab84d28245_m.jpg" width="240" height="180" alt="Aperitif" /></a>
 </div>
*** Output of to_latex ***

*** Output of to_md ***

*** Output of to_s ***


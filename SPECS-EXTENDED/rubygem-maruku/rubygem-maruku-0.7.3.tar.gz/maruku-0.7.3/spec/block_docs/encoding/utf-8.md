Write a comment abouth the test here.
*** Parameters: ***
{:italian=>"\303\240\303\250\303\254\303\262\303\271."}
*** Markdown input: ***
Italian: àèìòù.

Japanese: マルク

*** Output of inspect ***
md_el(:document,[md_par(["Japanese: \343\203\236\343\203\253\343\202\257"])],{},[])
*** Output of to_html ***
<p>Japanese: マルク</p>
*** Output of to_latex ***
Japanese: マルク
*** Output of to_md ***
Japanese: マルク
*** Output of to_s ***
Japanese: マルク

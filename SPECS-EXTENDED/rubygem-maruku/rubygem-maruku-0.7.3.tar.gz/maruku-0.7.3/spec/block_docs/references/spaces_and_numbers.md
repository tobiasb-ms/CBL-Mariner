Spaces can be put before. ID can be a number
*** Parameters: ***
{}
*** Markdown input: ***
  [6]: http://ettext.taint.org/doc/
*** Output of inspect ***
md_el(:document,[md_ref_def("6", "http://ettext.taint.org/doc/", {:title=>nil})],{},[])
*** Output of to_html ***

*** Output of to_latex ***

*** Output of to_md ***

*** Output of to_s ***


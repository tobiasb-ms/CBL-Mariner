Write a comment here
*** Parameters: ***
{} # params 
*** Markdown input: ***
[test][]:

*** Output of inspect ***
md_el(:document,[md_par([md_link(["test"], ""), ":"])],{},[])
*** Output of to_html ***
<p>[test][]:</p>
*** Output of to_latex ***
test:
*** Output of to_md ***
[test][]:
*** Output of to_s ***
test:

## Option number 1 ##

*	`[ ]{0,3}\+={2,}` pushes the stack
*	`[ ]{0,3}\-={2,}` pops the stack

	+================ {#id}
		IAL can be put on the same line of a push
		
	 +== {#id2}
		Or on the same line of a pop:
	 -==
	
	-==============

## Option number 2 ##

Double braces:

	{{
	
	}}{}

I don't like, it gets too messy because there are 
too many braces.



    +================ {#id}
    
         nested div:

     +========================
           inside nested DIV
     -========================

    -==============

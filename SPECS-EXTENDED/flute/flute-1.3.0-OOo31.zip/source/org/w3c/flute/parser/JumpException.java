/*
 * (c) COPYRIGHT 1999 World Wide Web Consortium
 * (Massachusetts Institute of Technology, Institut National de Recherche
 *  en Informatique et en Automatique, Keio University).
 * All Rights Reserved. http://www.w3.org/Consortium/Legal/
 *
 * $Id: JumpException.java 6653 2008-12-02 14:53:40Z tmorgner $
 */
package org.w3c.flute.parser;

/**
 * @version $Revision: 6653 $
 * @author  Philippe Le Hegaret
 */
public class JumpException extends RuntimeException {
    /**
     * Creates a new JumpException
     */
    public JumpException() {
    }
    
}

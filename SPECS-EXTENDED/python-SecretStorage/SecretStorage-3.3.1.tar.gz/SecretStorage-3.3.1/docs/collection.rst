=======================================
The ``secretstorage.collection`` module
=======================================

.. automodule:: secretstorage.collection
   :members:

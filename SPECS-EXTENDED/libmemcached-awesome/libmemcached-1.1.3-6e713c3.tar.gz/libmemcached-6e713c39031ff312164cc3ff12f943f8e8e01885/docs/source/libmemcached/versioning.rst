libmemcached Versioning
=======================

Libmemcached is laid out by interface version. The 1.0 version would be found
in: ``libmemcached-1.0/memcached.h``

The historic ``libmemcached/memcached.h`` includes
``libmemcached-1.0/memcached.h``. For best practice you should include the
version of libmemcached that you used during development.


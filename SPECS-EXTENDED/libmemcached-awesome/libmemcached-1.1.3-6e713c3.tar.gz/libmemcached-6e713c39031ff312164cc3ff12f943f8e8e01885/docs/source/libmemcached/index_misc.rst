Miscellaneous
=============

.. toctree::
    :maxdepth: 1

    Configuration <configuration>
    Constants <constants>
    Examples <examples>
    Versioning <versioning>

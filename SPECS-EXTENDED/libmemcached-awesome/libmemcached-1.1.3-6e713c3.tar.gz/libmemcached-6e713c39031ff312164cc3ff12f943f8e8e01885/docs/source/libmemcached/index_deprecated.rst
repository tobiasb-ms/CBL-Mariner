Deprecated Functionality
========================

.. toctree::
    :titlesonly:

    memcached_fetch


Messages and Errors
===================

.. toctree::
    :titlesonly:

    memcached_return_t
    memcached_last_error
    memcached_strerror

package com.lmax.disruptor.immutable;

public class Constants
{
    public static final long ITERATIONS = 1000 * 1000 * 100L;
    public static final int SIZE = 1 << 20;
}

=======================
Sushy Library Reference
=======================

Usage
=====

.. toctree::
   :maxdepth: 2

   usage

Sushy Python API Reference
==========================

* :ref:`modindex`

.. # api/modules is hidden since it's in the modindex link above.
.. toctree::
  :hidden:

  api/modules

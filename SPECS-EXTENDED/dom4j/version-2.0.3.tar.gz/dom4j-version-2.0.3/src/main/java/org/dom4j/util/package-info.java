/**
 * A collection of utility classes for the <i>dom4j</i> API.
 */
package org.dom4j.util;
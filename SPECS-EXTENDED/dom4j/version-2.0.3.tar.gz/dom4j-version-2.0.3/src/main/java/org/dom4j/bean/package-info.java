/**
 * An implementation of the <i>dom4j</i> API which allows JavaBeans to be used to store and retrieve attribute values from Element.
 */
package org.dom4j.bean;
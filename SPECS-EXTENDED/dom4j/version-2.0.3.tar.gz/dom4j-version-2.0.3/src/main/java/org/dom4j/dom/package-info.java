/**
 * An implementation of the <i>dom4j</i> API which also supports the W3C object model.
 */
package org.dom4j.dom;
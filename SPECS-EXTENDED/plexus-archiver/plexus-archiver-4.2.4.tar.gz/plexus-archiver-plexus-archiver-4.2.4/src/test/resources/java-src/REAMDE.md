This is the source code for the Java classes
inside `java-classes` and `java-module`  directories.

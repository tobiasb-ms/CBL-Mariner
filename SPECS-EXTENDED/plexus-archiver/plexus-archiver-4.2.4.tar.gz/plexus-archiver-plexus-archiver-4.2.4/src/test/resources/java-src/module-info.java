module com.example.app
{
    exports com.example.app;
}


This is tigrigna dictionary for open office.
It is produced by newGXP crawler distributed under GNU GPL license. 

Author: B. Gebremchael - http://www.cs.ru.nl/~biniam/geez/install.php
Version: ti_ER0.95
First release: 22 Nov 2007
Revised version: 11 Sept 2009


INSTALLATION

1. Copy ti_ER.dic and ti_ER.aff to open office dictionary directory. 
This directory is usually in "C:\program files\openoffice.org version\share\dict\ooo\" 

2. Put the following line to dictionary.lst (which is in the same directory as above)

DICT ti ER ti_ER

3. Set document language to the language you want to work with.

For more information see the http://www.cs.ru.nl/~biniam/geez/install.php

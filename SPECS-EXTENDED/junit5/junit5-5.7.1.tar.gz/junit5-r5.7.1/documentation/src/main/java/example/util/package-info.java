/**
 * Demo utilities.
 */

package example.util;

Why does this module not have any source code?

This module re-packages the JAR from the java6 version, replacing the SnakeYaml dependency with the latest version (which requires Java >= 7).
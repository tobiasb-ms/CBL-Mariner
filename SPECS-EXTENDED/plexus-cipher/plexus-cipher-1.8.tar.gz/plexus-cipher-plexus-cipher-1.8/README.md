Plexus-Cipher
============

[![Build Status](https://travis-ci.org/codehaus-plexus/plexus-cipher.svg?branch=master)](https://travis-ci.org/codehaus-plexus/plexus-cipher)
[![Maven Central](https://img.shields.io/maven-central/v/org.codehaus.plexus/plexus-cipher.svg?label=Maven%20Central)](http://search.maven.org/#search%7Cga%7C1%7Cg%3A%22org.codehaus.plexus%22%20a%3A%plexus-cipher%22)

The current master is now at https://github.com/codehaus-plexus/plexus-cipher

For publishing [the site](https://codehaus-plexus.github.io/plexus-cipher/) do the following:

```
mvn -Preporting verify site site:stage scm-publish:publish-scm
```

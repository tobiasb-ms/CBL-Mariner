[![Translation status](https://translate.fedoraproject.org/widgets/python-meh/-/master/svg-badge.svg)](https://translate.fedoraproject.org/engage/python-meh/?utm_source=widget)

Python Meh
==========

The python-meh package is a python library for handling, saving, and reporting exceptions.

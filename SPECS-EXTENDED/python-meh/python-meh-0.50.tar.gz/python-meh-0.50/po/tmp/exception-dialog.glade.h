char *s = N_("An unknown error has occurred");
char *s = N_("This program has encountered an unknown error. You may\n"
             "report the bug below or quit the program.");
char *s = N_("_Report Bug");
char *s = N_("_Quit");
char *s = N_("The output below may help determine the cause of the error:");
char *s = N_("'Debug' may take you to tty1.");
char *s = N_("_Debug");
char *s = N_("More _info...");
char *s = N_("No additional info available.");

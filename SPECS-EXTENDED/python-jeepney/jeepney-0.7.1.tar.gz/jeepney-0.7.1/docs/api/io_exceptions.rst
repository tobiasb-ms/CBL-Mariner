I/O Exceptions
==============

.. currentmodule:: jeepney.io

.. autoexception:: RouterClosed

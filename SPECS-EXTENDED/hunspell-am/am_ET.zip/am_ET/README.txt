
This is Amharic dictionary for open office.
It is produced by newGXP crawler distributed under GNU GPL license. 

Author: M. Goitom <newgxp@gmail.com>
Version: am_ET0.9
Date: 22 Nov 2007
Last modified: 4 July 2009


INSTALLATION

1. Copy am_ET.dic and am_ET.aff to open office dictionary directory. 
This directory is usually in "C:\program files\openoffice.org 2.0\share\dict\ooo\" for OO version 2.0

2. Put the following line to dictionary.lst (which is in the same directory as above)

DICT am ET am_ET

3. Set document language to the language you want to work with.

For more information see newGXP website 

package io.prometheus.client.servlet.common.exporter;

public class ServletConfigurationException extends Exception {
}

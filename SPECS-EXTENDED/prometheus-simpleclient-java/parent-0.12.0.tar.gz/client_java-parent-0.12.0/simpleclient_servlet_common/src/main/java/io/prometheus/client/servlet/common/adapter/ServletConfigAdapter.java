package io.prometheus.client.servlet.common.adapter;

public interface ServletConfigAdapter {
    String getInitParameter(String name);
}

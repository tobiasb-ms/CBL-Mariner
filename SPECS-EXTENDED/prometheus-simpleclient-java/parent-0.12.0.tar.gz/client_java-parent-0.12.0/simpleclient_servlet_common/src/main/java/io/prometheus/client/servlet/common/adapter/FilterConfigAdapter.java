package io.prometheus.client.servlet.common.adapter;

public interface FilterConfigAdapter {
    String getInitParameter(String name);
}

[![build status](https://img.shields.io/github/workflow/status/fedora-java/xmvn-connector-ivy/Maven%20Build/master.svg)](https://github.com/fedora-java/xmvn-connector-ivy/actions/workflows/maven.yml?query=branch%3Amaster)


This is free software. You can redistribute and/or modify it under the
terms of Apache License Version 2.0.

XMvn connector for Apache Ivy was written by Mikolaj Izdebski.

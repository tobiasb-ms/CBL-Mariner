==========================================
 ``celery.backends.filesystem``
==========================================

.. contents::
    :local:
.. currentmodule:: celery.backends.filesystem

.. automodule:: celery.backends.filesystem
    :members:
    :undoc-members:

================================================
 ``celery.backends.cassandra``
================================================

.. contents::
    :local:
.. currentmodule:: celery.backends.cassandra

.. automodule:: celery.backends.cassandra
    :members:
    :undoc-members:

=====================================================
 ``celery.utils.functional``
=====================================================

.. contents::
    :local:
.. currentmodule:: celery.utils.functional

.. automodule:: celery.utils.functional
    :members:
    :undoc-members:

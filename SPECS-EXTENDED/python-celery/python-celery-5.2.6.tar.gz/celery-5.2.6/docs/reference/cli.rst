=======================
 Command Line Interface
=======================

.. click:: celery.bin.celery:celery
   :prog: celery
   :nested: full

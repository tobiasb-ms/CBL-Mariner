module Tree = Tree
(** @canonical Odoc_html.Tree *)

module Generator = Generator
module Link = Link

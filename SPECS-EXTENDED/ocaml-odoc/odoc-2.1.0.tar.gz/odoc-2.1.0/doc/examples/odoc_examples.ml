(** Examples of the output from [odoc] *)

(** These examples are intended to be viewed alongside the
    source code. See {:https://github.com/ocaml/odoc/tree/master/doc/examples} *)

module Expansion = Expansion
module Resolution = Resolution
module Wrapping = Wrapping
module Markup = Markup

# Plexus Language
[![Build Status](https://travis-ci.org/codehaus-plexus/plexus-languages.svg?branch=master)](https://travis-ci.org/codehaus-plexus/plexus-languages)

Plexus Languages:

 * [![Maven Central](https://img.shields.io/maven-central/v/org.codehaus.plexus/plexus-languages.svg?label=Maven%20Central)](http://search.maven.org/#search%7Cga%7C1%7Cg%3A%22org.codehaus.plexus%22%20a%3A%22plexus-languages%22)

Plexus Java:

 * [![Maven Central](https://img.shields.io/maven-central/v/org.codehaus.plexus/plexus-java.svg?label=Maven%20Central)](http://search.maven.org/#search%7Cga%7C1%7Cg%3A%22org.codehaus.plexus%22%20a%3A%22plexus-java%22)

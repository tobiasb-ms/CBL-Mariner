#!/bin/sh

javac -cp ../jar1.jar Main.java
jar cvf ../jar3using1.jar .
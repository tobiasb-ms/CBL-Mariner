package org.codehaus.mojo.exec;

public class Main
{

    //Take care: No array as args.
    public static void main( String args )
    {
    }
}

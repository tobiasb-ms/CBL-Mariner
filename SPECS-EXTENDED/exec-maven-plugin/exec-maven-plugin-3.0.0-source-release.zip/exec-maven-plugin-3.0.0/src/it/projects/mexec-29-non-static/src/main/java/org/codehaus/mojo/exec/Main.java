package org.codehaus.mojo.exec;

public class Main
{

    // Watch it: not static!!
    public void main( String[] args )
    {
    }
}

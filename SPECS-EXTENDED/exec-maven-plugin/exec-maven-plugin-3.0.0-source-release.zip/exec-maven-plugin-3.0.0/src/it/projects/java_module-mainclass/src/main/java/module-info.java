module com.greetings {
    requires plexus.utils;
}
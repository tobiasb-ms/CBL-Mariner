module exec.boot
{
  requires plexus.utils;
  
  exports org.mojohaus.exec;
}
module com.greetings {
    exports com.greetings;

    requires plexus.utils;
}
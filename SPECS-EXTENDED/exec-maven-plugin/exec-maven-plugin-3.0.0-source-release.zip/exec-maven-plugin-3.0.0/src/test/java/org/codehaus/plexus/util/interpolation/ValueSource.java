package org.codehaus.plexus.util.interpolation;

/**
 * COPIED FROM plexus-utils-1.5.15 TO SATISFY TESTS
 * 
 * @author jdcasey
 * @deprecated Use plexus-interpolation APIs instead.
 * @version $Id$
 */
public interface ValueSource
    extends org.codehaus.plexus.interpolation.ValueSource
{

}

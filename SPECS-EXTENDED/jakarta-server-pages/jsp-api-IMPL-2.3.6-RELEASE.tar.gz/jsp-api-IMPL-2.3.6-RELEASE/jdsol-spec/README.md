Jakarta Debugging Support for Other Languages Specification
============================

This project generates the Jakarta Debugging Support for Other Languages.

Building
--------

Prerequisites:

* JDK8+
* Maven 3.0.3+

Run the full build:

`mvn install`

Locate the html files:
- `target/generated-docs/jdsol-spec-1_0.html`

Locate the PDF files:
- `target/generated-docs/jdsol-spec-1_0.pdf`

# Prerequisites

Oracle JDK 1.7 

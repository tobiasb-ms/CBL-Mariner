=======
Lexicon
=======

This is just a dummy Sphinx project for hosting the changelog. Please see the
top level ``README.rst`` for all non-changelog documentation.

.. toctree::
    :maxdepth: 1

    changelog

extern const char * _notification_watcher;

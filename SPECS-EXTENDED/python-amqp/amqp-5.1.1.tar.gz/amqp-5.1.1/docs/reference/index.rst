.. _apiref:

===============
 API Reference
===============

:Release: |version|
:Date: |today|

.. toctree::
    :maxdepth: 1

    amqp.connection
    amqp.channel
    amqp.basic_message
    amqp.exceptions
    amqp.abstract_channel
    amqp.transport
    amqp.method_framing
    amqp.platform
    amqp.protocol
    amqp.sasl
    amqp.serialization
    amqp.spec
    amqp.utils

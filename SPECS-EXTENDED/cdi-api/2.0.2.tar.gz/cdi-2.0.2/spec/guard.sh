#!/usr/bin/env bash
bundle exec guard

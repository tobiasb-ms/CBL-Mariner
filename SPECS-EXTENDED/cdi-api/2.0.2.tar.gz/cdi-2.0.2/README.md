# Check out the [cdi-spec.org](http://cdi-spec.org) for more info on CDI 2.0 and CDI 1.2

Sources in GIT
====

Master contains the work-in-progress on CDI 2.0 specification

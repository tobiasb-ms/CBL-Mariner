/**
 * This package provides classes for processing JSON in an efficient streaming way.
 */
package com.google.gson.stream;
